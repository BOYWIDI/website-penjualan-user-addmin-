<?php 
    require 'koneksi.php'; // Pastikan file ini menghubungkan ke database

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $id_barang = htmlspecialchars($_POST['id_barang']);
        $jumlah = (int)$_POST['jumlah'];
        $total = (int)$_POST['total'];
        $tgl = date("Y-m-d H:i:s"); // Dapatkan tanggal dan waktu saat ini

        $sql = "INSERT INTO nota (id_barang, jumlah, total, tanggal_input) VALUES (?, ?, ?, ?)";
        $stmt = $config->prepare($sql);
        $stmt->bind_param("sdis", $id_barang, $jumlah, $total, $tgl);
        
        if ($stmt->execute()) {
            // Sukses, alihkan atau tampilkan pesan sukses
            header('Location: ../index.php?page=jual&success=true');
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }
    }
?>