<h4>Data Penjualan</h4>
<br />
<button type="button" class="btn btn-primary btn-md mr-2" data-toggle="modal" data-target="#modalJual">
    <i class="fa fa-plus"></i> Tambah Penjualan
</button>
<br /><br />
<div class="card card-body">
    <div class="table-responsive">
        <table class="table table-bordered table-striped table-sm" id="example2">
            <thead>
                <tr style="background:#DFF0D8;color:#333;">
                    <th>No.</th>
                    <th>ID Nota</th>
                    <th>ID Barang</th>
                    <th>Jumlah</th>
                    <th>Total</th>
                    <th>Tanggal Input</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    // Ambil dan tampilkan data penjualan
                    $sql = "SELECT * FROM nota ORDER BY id_nota DESC";
                    $row = $config->prepare($sql);
                    $row->execute();
                    $hasil = $row->fetchAll();
                    $no = 1;
                    foreach($hasil as $isi) {
                ?>
                <tr>
                    <td><?php echo $no;?></td>
                    <td><?php echo htmlspecialchars($isi['id_nota'], ENT_QUOTES, 'UTF-8');?></td>
                    <td><?php echo htmlspecialchars($isi['id_barang'], ENT_QUOTES, 'UTF-8');?></td>
                    <td><?php echo htmlspecialchars($isi['jumlah'], ENT_QUOTES, 'UTF-8');?></td>
                    <td>Rp.<?php echo number_format($isi['total']);?>,-</td>
                    <td><?php echo htmlspecialchars($isi['tanggal_input'], ENT_QUOTES, 'UTF-8');?></td>
                    <td><a href="fungsi/hapus/hapus.php?jual=hapus&id=<?php echo urlencode($isi['id_nota']);?>&csrf_token=<?php echo urlencode(csrf_get_token());?>"
                           onclick="javascript:return confirm('Hapus Data penjualan ?');"><button class="btn btn-danger btn-xs">Hapus</button></a></td>
                </tr>
                <?php $no++; } ?>
            </tbody>
        </table>
    </div>
</div>

<div id="modalJual" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content" style="border-radius:0px;">
            <div class="modal-header" style="background:#285c64;color:#fff;">
                <h5 class="modal-title"><i class="fa fa-plus"></i> Tambah Penjualan</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <form action="fungsi/tambah/tambah_nota.php" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <table class="table table-striped bordered">
                        <tr>
                            <td>ID Barang</td>
                            <td>
                                <select name="id_barang" class="form-control" required>
                                    <option value="#">Pilih Barang</option>
                                    <?php 
                                        $brg = $lihat->barang(); 
                                        foreach($brg as $isi){
                                    ?>
                                    <option value="<?= htmlspecialchars($isi['id_barang'], ENT_QUOTES, 'UTF-8'); ?>">
                                        <?= htmlspecialchars($isi['nama_barang'], ENT_QUOTES, 'UTF-8'); ?> (Stok: <?= htmlspecialchars($isi['stok'], ENT_QUOTES, 'UTF-8'); ?>)
                                    </option>
                                    <?php }?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td>Jumlah</td>
                            <td><input type="number" placeholder="Jumlah" required class="form-control" name="jumlah"></td>
                        </tr>
                        <tr>
                            <td>Total</td>
                            <td><input type="number" placeholder="Total Harga" required class="form-control" name="total"></td>
                        </tr>
                    </table>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary"><i class="fa fa-plus"></i> Tambah</button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
                </div>
            </form>
        </div>
    </div>
</div>