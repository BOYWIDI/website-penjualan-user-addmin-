<h4>Manajemen Pengguna</h4>
<br />
<button type="button" class="btn btn-primary btn-md mr-2" data-toggle="modal" data-target="#modalUser">
    <i class="fa fa-plus"></i> Tambah Pengguna
</button>
<br /><br />
<div class="card card-body">
    <div class="table-responsive">
        <table class="table table-bordered table-striped table-sm" id="example3">
            <thead>
                <tr style="background:#DFF0D8;color:#333;">
                    <th>No.</th>
                    <th>Username</th>
                    <th>Level</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    // Ambil dan tampilkan data pengguna
                    $sql = "SELECT * FROM login";
                    $row = $config->prepare($sql);
                    $row->execute();
                    $hasil = $row->fetchAll();
                    $no = 1;
                    foreach($hasil as $isi) {
                ?>
                <tr>
                    <td><?php echo $no;?></td>
                    <td><?php echo htmlspecialchars($isi['user'], ENT_QUOTES, 'UTF-8');?></td>
                    <td><?php echo htmlspecialchars($isi['level'], ENT_QUOTES, 'UTF-8');?></td>
                    <td>
                        <a href="fungsi/hapus/hapus.php?user=hapus&id=<?php echo urlencode($isi['id_login']);?>&csrf_token=<?php echo urlencode(csrf_get_token());?>"
                           onclick="javascript:return confirm('Hapus Data pengguna ?');"><button class="btn btn-danger btn-xs">Hapus</button></a>
                    </td>
                </tr>
                <?php $no++; } ?>
            </tbody>
        </table>
    </div>
</div>

<div id="modalUser" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content" style="border-radius:0px;">
            <div class="modal-header" style="background:#285c64;color:#fff;">
                <h5 class="modal-title"><i class="fa fa-plus"></i> Tambah Pengguna</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <form action="fungsi/tambah/tambah_user.php" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <table class="table table-striped bordered">
                        <tr>
                            <td>Username</td>
                            <td><input type="text" placeholder="Username" required class="form-control" name="user"></td>
                        </tr>
                        <tr>
                            <td>Password</td>
                            <td><input type="password" placeholder="Password" required class="form-control" name="pass"></td>
                        </tr>
                        <tr>
                            <td>Level</td>
                            <td>
                                <select name="level" class="form-control" required>
                                    <option value="admin">Admin</option>
                                    <option value="staff">Staff</option>
                                </select>
                            </td>
                        </tr>
                    </table>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary"><i class="fa fa-plus"></i> Tambah</button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
                </div>
            </form>
        </div>
    </div>
</div>