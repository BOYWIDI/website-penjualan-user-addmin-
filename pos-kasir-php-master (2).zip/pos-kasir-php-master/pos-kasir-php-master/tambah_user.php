<?php
    require 'koneksi.php'; // Pastikan file ini menghubungkan ke database

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $user = htmlspecialchars($_POST['user']);
        $pass = htmlspecialchars($_POST['pass']);
        $level = htmlspecialchars($_POST['level']);

        // Hash kata sandi untuk keamanan
        $hashed_password = password_hash($pass, PASSWORD_DEFAULT);

        $sql = "INSERT INTO login (user, pass, level) VALUES (?, ?, ?)";
        $stmt = $config->prepare($sql);
        $stmt->bind_param("sss", $user, $hashed_password, $level);
        
        if ($stmt->execute()) {
            // Sukses, alihkan atau tampilkan pesan sukses
            header('Location: ../index.php?page=user&success=true');
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }
    }
?>